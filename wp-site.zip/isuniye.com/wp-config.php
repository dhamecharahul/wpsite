<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

define('FS_METHOD','direct');

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'isuniye_103');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', 'admin');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         ')`v!n,RZENI!ok=g|h.!2iv7vd0u2{.5T03{AR.;7v{PAycQk2s(#}%]Pl;oP]#5');
define('SECURE_AUTH_KEY',  '>mQjaEfxFEppK>?ZG!(V6rh;4>?<:Dl7!SjZ-!WeR^4p;9bn.b)$7ou@~o|l*NB-');
define('LOGGED_IN_KEY',    'G~Id[(1!PH&9_dilOZeEyaHxxeeVDSIL`*zc%2E#<qa$M=JyOmq8c<d!3a7J!~w4');
define('NONCE_KEY',        ']X0sdf!lf^EN<V.twR!|Kg]6V6;M#y8lDe3Gy2)e(nkLcEX@-h[s[SSLj(8ij#Y=');
define('AUTH_SALT',        'P/>g u[~dHxO-V&Y{q-U,o_Uht?x#Ji7KSX0r<hmd?[9v?I2kh9X_)=rl8$Ai(A_');
define('SECURE_AUTH_SALT', '%uo3}!ai $`e==C[41FuD{SF6$^[X9{KxGuN0lgyteL*eet!JU?:o:YHLe&:=s}?');
define('LOGGED_IN_SALT',   '4kT^W_NLJ!.uPToDy=OF$_Pb,TY/#|{;y<~w]S;0MoQ(j0bY0UHV>(sI:AEd>fq:');
define('NONCE_SALT',       'l7;Bh@gdxx<{].caxkb{awWeaPT>Q/<6+YJ~Xo)&Cd<oLd;i..=0Jve y;xoglnz');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'isuniye_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
